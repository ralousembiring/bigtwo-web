import React, { useEffect, useMemo, useRef, useState } from "react";
import { PlayerCard } from "./PlayerCard";
import { drawCard, tenGacha } from "./gacha";
import { getCardById } from "./cards";
import { db } from "../firebase";
import { onValue, ref, set } from "firebase/database";

const GOLD = "#C9A227";
const CREAM = "#F5EFE0";
const BG = "#17110E";
const PANEL = "#24201C";
const PANEL_SOFT = "#2A2520";
const SINGLE_COST = 20;
const TEN_COST = 200;
const INITIAL_COINS = 0;
const FIRST_DAY_COINS = 400;
const DAILY_COINS = 200;
const MAX_SQUAD = 11;

const FORMATIONS = {
  "4-3-3": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 16, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 84, y: 70 },
    { id: "CM1", label: "CM", x: 30, y: 52 },
    { id: "CM2", label: "CM", x: 70, y: 52 },
    { id: "CDM", label: "CDM", x: 50, y: 62 },
    { id: "LW", label: "LW", x: 20, y: 28 },
    { id: "ST", label: "ST", x: 50, y: 20 },
    { id: "RW", label: "RW", x: 80, y: 28 },
  ],
  "4-4-2": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "LM", label: "LM", x: 15, y: 48 },
    { id: "CM1", label: "CM", x: 38, y: 53 },
    { id: "CM2", label: "CM", x: 62, y: 53 },
    { id: "RM", label: "RM", x: 85, y: 48 },
    { id: "ST1", label: "ST", x: 40, y: 22 },
    { id: "ST2", label: "ST", x: 60, y: 22 },
  ],
  "4-2-3-1": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "CDM1", label: "CDM", x: 38, y: 57 },
    { id: "CDM2", label: "CDM", x: 62, y: 57 },
    { id: "LW", label: "LW", x: 20, y: 37 },
    { id: "CAM", label: "CAM", x: 50, y: 35 },
    { id: "RW", label: "RW", x: 80, y: 37 },
    { id: "ST", label: "ST", x: 50, y: 19 },
  ],
  "4-3-1-2": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "CM1", label: "CM", x: 28, y: 53 },
    { id: "CDM", label: "CDM", x: 50, y: 59 },
    { id: "CM2", label: "CM", x: 72, y: 53 },
    { id: "CAM", label: "CAM", x: 50, y: 36 },
    { id: "ST1", label: "ST", x: 40, y: 19 },
    { id: "ST2", label: "ST", x: 60, y: 19 },
  ],
  "4-1-4-1": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "CDM", label: "CDM", x: 50, y: 59 },
    { id: "LM", label: "LM", x: 15, y: 43 },
    { id: "CM1", label: "CM", x: 38, y: 46 },
    { id: "CM2", label: "CM", x: 62, y: 46 },
    { id: "RM", label: "RM", x: 85, y: 43 },
    { id: "ST", label: "ST", x: 50, y: 20 },
  ],
  "3-5-2": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "CB1", label: "CB", x: 27, y: 72 },
    { id: "CB2", label: "CB", x: 50, y: 75 },
    { id: "CB3", label: "CB", x: 73, y: 72 },
    { id: "LM", label: "LM", x: 10, y: 50 },
    { id: "CM1", label: "CM", x: 30, y: 53 },
    { id: "CDM", label: "CDM", x: 50, y: 58 },
    { id: "CM2", label: "CM", x: 70, y: 53 },
    { id: "RM", label: "RM", x: 90, y: 50 },
    { id: "ST1", label: "ST", x: 40, y: 22 },
    { id: "ST2", label: "ST", x: 60, y: 22 },
  ],
  "3-4-3": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "CB1", label: "CB", x: 27, y: 73 },
    { id: "CB2", label: "CB", x: 50, y: 75 },
    { id: "CB3", label: "CB", x: 73, y: 73 },
    { id: "LM", label: "LM", x: 15, y: 50 },
    { id: "CM1", label: "CM", x: 38, y: 53 },
    { id: "CM2", label: "CM", x: 62, y: 53 },
    { id: "RM", label: "RM", x: 85, y: 50 },
    { id: "LW", label: "LW", x: 20, y: 25 },
    { id: "ST", label: "ST", x: 50, y: 19 },
    { id: "RW", label: "RW", x: 80, y: 25 },
  ],
  "5-3-2": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LWB", label: "LWB", x: 8, y: 65 },
    { id: "CB1", label: "CB", x: 30, y: 73 },
    { id: "CB2", label: "CB", x: 50, y: 75 },
    { id: "CB3", label: "CB", x: 70, y: 73 },
    { id: "RWB", label: "RWB", x: 92, y: 65 },
    { id: "CM1", label: "CM", x: 30, y: 50 },
    { id: "CDM", label: "CDM", x: 50, y: 56 },
    { id: "CM2", label: "CM", x: 70, y: 50 },
    { id: "ST1", label: "ST", x: 40, y: 21 },
    { id: "ST2", label: "ST", x: 60, y: 21 },
  ],
  "5-2-3": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LWB", label: "LWB", x: 8, y: 65 },
    { id: "CB1", label: "CB", x: 30, y: 73 },
    { id: "CB2", label: "CB", x: 50, y: 75 },
    { id: "CB3", label: "CB", x: 70, y: 73 },
    { id: "RWB", label: "RWB", x: 92, y: 65 },
    { id: "CM1", label: "CM", x: 38, y: 53 },
    { id: "CM2", label: "CM", x: 62, y: 53 },
    { id: "LW", label: "LW", x: 20, y: 25 },
    { id: "ST", label: "ST", x: 50, y: 19 },
    { id: "RW", label: "RW", x: 80, y: 25 },
  ],
  "4-2-2-2": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "CDM1", label: "CDM", x: 38, y: 56 },
    { id: "CDM2", label: "CDM", x: 62, y: 56 },
    { id: "CAM1", label: "CAM", x: 30, y: 36 },
    { id: "CAM2", label: "CAM", x: 70, y: 36 },
    { id: "ST1", label: "ST", x: 40, y: 19 },
    { id: "ST2", label: "ST", x: 60, y: 19 },
  ],
  "4-3-2-1": [
    { id: "GK", label: "GK", x: 50, y: 88 },
    { id: "LB", label: "LB", x: 15, y: 70 },
    { id: "CB1", label: "CB", x: 38, y: 73 },
    { id: "CB2", label: "CB", x: 62, y: 73 },
    { id: "RB", label: "RB", x: 85, y: 70 },
    { id: "CM1", label: "CM", x: 28, y: 53 },
    { id: "CDM", label: "CDM", x: 50, y: 59 },
    { id: "CM2", label: "CM", x: 72, y: 53 },
    { id: "CAM1", label: "CAM", x: 37, y: 33 },
    { id: "CAM2", label: "CAM", x: 63, y: 33 },
    { id: "ST", label: "ST", x: 50, y: 19 },
  ],
};

function getPlayerKey() {
  const saved = localStorage.getItem("ralouFootballPlayerId");
  if (saved) return saved;

  const newId =
    "football_" +
    Date.now() +
    "_" +
    Math.random().toString(36).slice(2, 9);

  localStorage.setItem("ralouFootballPlayerId", newId);
  return newId;
}

function getLocalKey(playerKey) {
  return `ralouFootballSave_${playerKey}`;
}

function readLocalSave(playerKey) {
  try {
    const raw = localStorage.getItem(getLocalKey(playerKey));
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function normalizeSquad(rawSquad) {
  if (!rawSquad) return {};

  if (typeof rawSquad === "object" && !Array.isArray(rawSquad)) {
    return rawSquad;
  }

  if (Array.isArray(rawSquad)) {
    const slots = FORMATIONS["4-3-3"];
    const result = {};
    rawSquad.forEach((cardId, index) => {
      if (slots[index]) result[slots[index].id] = cardId;
    });
    return result;
  }

  return {};
}

function normalizeHistory(raw) {
  return Array.isArray(raw) ? raw.slice(0, 20) : [];
}

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(d.getDate()).padStart(2, "0")}`;
}

function getPositionGroup(position) {
  const groups = {
    GK: ["GK"],
    LB: ["LB", "LWB"],
    LWB: ["LB", "LWB", "LM"],
    RB: ["RB", "RWB"],
    RWB: ["RB", "RWB", "RM"],
    CB: ["CB"],
    CDM: ["CDM", "CM", "CAM"],
    CM: ["CM", "CDM", "CAM", "LM", "RM"],
    CAM: ["CAM", "CM", "CDM", "CF", "ST"],
    LM: ["LM", "LWB", "CM", "LW"],
    RM: ["RM", "RWB", "CM", "RW"],
    LW: ["LW", "LM", "RW", "CAM", "CF", "ST"],
    RW: ["RW", "RM", "LW", "CAM", "CF", "ST"],
    CF: ["CF", "CAM", "ST", "LW", "RW"],
    ST: ["ST", "CF", "CAM", "LW", "RW"],
  };

  return groups[position] || [position];
}

function isCompatiblePosition(card, slotPosition) {
  if (!card) return false;

  if (slotPosition === "GK") {
    return card.position === "GK";
  }

  if (card.position === "GK") return false;

  const cardPositions = getPositionGroup(card.position);
  const slotPositions = getPositionGroup(slotPosition);

  return (
    cardPositions.some((position) => slotPositions.includes(position)) ||
    card.position === slotPosition
  );
}

function getSquadPlayers(squad) {
  return Object.entries(squad)
    .map(([slotId, cardId]) => {
      const card = getCardById(cardId);
      return card ? { slotId, card } : null;
    })
    .filter(Boolean);
}

function getTeamOverall(squad) {
  const players = getSquadPlayers(squad);
  if (players.length === 0) return 0;

  const total = players.reduce((sum, item) => sum + item.card.overall, 0);
  return Math.round(total / players.length);
}

function getSquadStrength(squad) {
  const players = getSquadPlayers(squad);
  if (players.length === 0) return 0;

  const total = players.reduce((sum, item) => {
    const c = item.card;
    const main =
      c.position === "GK"
        ? (c.awareness + c.catching + c.reflexes + c.diving + c.jumping + c.physical) / 6
        : (c.pace + c.shooting + c.passing + c.dribbling + c.defending + c.physical) / 6;

    return sum + main;
  }, 0);

  return Math.round(total / players.length);
}

function makeOpponent(userOverall) {
  const base = userOverall || 65;
  const delta = Math.floor(Math.random() * 19) - 9;
  const overall = Math.max(55, Math.min(98, base + delta));

  const names = [
    "Jakarta United",
    "RGame FC",
    "Golden Lions",
    "Nusantara XI",
    "Royal Strikers",
    "Metro Stars",
    "Red Falcons",
    "Garuda City",
    "Thunder FC",
    "Capital Kings",
  ];

  return {
    name: names[Math.floor(Math.random() * names.length)],
    overall,
  };
}

function simulateMatch(userOverall, opponentOverall) {
  const homeStrength = Math.max(1, userOverall);
  const awayStrength = Math.max(1, opponentOverall);
  const events = [];

  let homeGoals = 0;
  let awayGoals = 0;
  let minute = 3;
  let possessionSide = Math.random() < 0.5 ? "home" : "away";

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

  function addEvent(type, side, text, x, y, extra = {}) {
    events.push({
      id: `${events.length}_${type}_${minute}`,
      minute,
      type,
      side,
      text,
      x: clamp(x, 3, 97),
      y: clamp(y, 4, 96),
      ...extra,
    });
  }

  function attackingPosition(side) {
    const x = 28 + Math.random() * 44;
    const y = side === "home"
      ? 45 - Math.random() * 27
      : 55 + Math.random() * 27;
    return { x, y };
  }

  while (minute < 89) {
    minute += 2 + Math.floor(Math.random() * 5);
    if (minute > 89) minute = 89;

    const side = possessionSide;
    const attack = side === "home" ? homeStrength : awayStrength;
    const defense = side === "home" ? awayStrength : homeStrength;
    const attackAdvantage = clamp((attack - defense) / 100, -0.22, 0.22);
    const chance = Math.random();
    const pos = attackingPosition(side);

    addEvent(
      "attack",
      side,
      side === "home"
        ? "🔵 Ralou FC membangun serangan dari lini tengah."
        : "🔴 Lawan mulai menekan dan membawa bola ke depan.",
      pos.x,
      pos.y
    );

    if (chance < 0.14) {
      addEvent(
        "foul",
        side === "home" ? "away" : "home",
        side === "home"
          ? "🟨 Bek lawan melakukan pelanggaran di area berbahaya."
          : "🟨 Pemain Ralou FC melakukan pelanggaran saat menghentikan serangan.",
        pos.x,
        pos.y,
        { foulAgainst: side }
      );

      const inBox = Math.random() < 0.22;
      if (inBox) {
        addEvent(
          "penalty",
          side,
          side === "home"
            ? "⚠️ PENALTY! Ralou FC mendapat tendangan penalti!"
            : "⚠️ PENALTY! Lawan mendapat tendangan penalti!",
          side === "home" ? 50 : 50,
          side === "home" ? 10 : 90
        );

        const penaltyChance = 0.68 + attackAdvantage * 0.7;
        if (Math.random() < penaltyChance) {
          if (side === "home") homeGoals += 1;
          else awayGoals += 1;
          addEvent(
            "goal",
            side,
            side === "home"
              ? "⚽ GOOOOOL! Penalti Ralou FC berhasil dieksekusi!"
              : "⚽ GOL! Lawan berhasil mencetak gol dari titik putih!",
            50,
            side === "home" ? 4 : 96
          );
        } else {
          addEvent(
            "penalty_miss",
            side,
            side === "home"
              ? "🧤 Penalti Ralou FC ditepis kiper!"
              : "🧤 Penalti lawan berhasil diselamatkan kiper Ralou FC!",
            50,
            side === "home" ? 7 : 93
          );
        }
      } else {
        addEvent(
          "freekick",
          side,
          side === "home"
            ? "🎯 FREE KICK untuk Ralou FC."
            : "🎯 FREE KICK untuk lawan.",
          pos.x,
          pos.y
        );

        if (Math.random() < 0.28 + attackAdvantage * 0.4) {
          addEvent(
            "shot",
            side,
            side === "home"
              ? "💥 Tendangan bebas Ralou FC mengarah ke gawang!"
              : "💥 Tendangan bebas lawan mengarah ke gawang Ralou FC!",
            28 + Math.random() * 44,
            side === "home" ? 24 : 76
          );
        }
      }
    } else if (chance < 0.28) {
      addEvent(
        "corner",
        side,
        side === "home"
          ? "🚩 CORNER! Bola dibuang bek lawan dan Ralou FC mendapat sepak pojok."
          : "🚩 CORNER! Lawan mendapat sepak pojok.",
        side === "home" ? (Math.random() < 0.5 ? 96 : 4) : (Math.random() < 0.5 ? 96 : 4),
        side === "home" ? (Math.random() < 0.5 ? 5 : 95) : (Math.random() < 0.5 ? 5 : 95)
      );
      if (Math.random() < 0.3) {
        addEvent(
          "header",
          side,
          side === "home"
            ? "🧠 Sundulan Ralou FC dari situasi corner!"
            : "🧠 Sundulan lawan dari situasi corner!",
          side === "home" ? 87 : 13,
          50
        );
      }
    } else if (chance < 0.43) {
      addEvent(
        "out",
        side,
        "↔️ Bola keluar lapangan. Lemparan ke dalam untuk lawan.",
        side === "home" ? 92 : 8,
        20 + Math.random() * 60
      );
    } else {
      const shotChance = 0.42 + attackAdvantage;
      if (Math.random() < shotChance) {
        addEvent(
          "shot",
          side,
          side === "home"
            ? "🎯 Ralou FC melepaskan tembakan!"
            : "🎯 Lawan melepaskan tembakan!",
          28 + Math.random() * 44,
          side === "home" ? 10 + Math.random() * 18 : 72 + Math.random() * 18
        );

        const goalChance = clamp(0.13 + attackAdvantage * 0.65 + Math.random() * 0.12, 0.06, 0.28);
        if (Math.random() < goalChance && (side === "home" ? homeGoals : awayGoals) < 5) {
          if (side === "home") homeGoals += 1;
          else awayGoals += 1;
          addEvent(
            "goal",
            side,
            side === "home"
              ? "⚽ GOOOOOL! Ralou FC berhasil menembus pertahanan!"
              : "⚽ GOL! Lawan berhasil menjebol gawang Ralou FC!",
            28 + Math.random() * 44,
            side === "home" ? 4 : 96
          );
        } else if (Math.random() < 0.55) {
          addEvent(
            "save",
            side === "home" ? "away" : "home",
            side === "home"
              ? "🧤 Kiper lawan melakukan penyelamatan!"
              : "🧤 Kiper Ralou FC menggagalkan peluang!",
            28 + Math.random() * 44,
            side === "home" ? 7 : 93
          );
        } else {
          addEvent(
            "miss",
            side,
            "💨 Tembakan melebar dari sasaran.",
            28 + Math.random() * 44,
            side === "home" ? 4 : 96
          );
        }
      } else {
        addEvent(
          "pass",
          side,
          side === "home"
            ? "🔵 Ralou FC terus bertukar umpan mencari celah."
            : "🔴 Lawan menguasai bola dan mencari ruang.",
          pos.x,
          pos.y
        );
      }
    }

    possessionSide = Math.random() < 0.52 ? (side === "home" ? "away" : "home") : side;
  }

  // Biar match tidak terasa kosong, selalu ada minimal satu peluang yang berujung gol.
  if (homeGoals + awayGoals === 0) {
    const forcedSide = Math.random() < homeStrength / (homeStrength + awayStrength) ? "home" : "away";
    const forcedMinute = 38 + Math.floor(Math.random() * 35);
    if (forcedSide === "home") homeGoals = 1;
    else awayGoals = 1;
    events.push({
      id: `forced_goal_${forcedMinute}`,
      minute: forcedMinute,
      type: "goal",
      side: forcedSide,
      text: forcedSide === "home"
        ? "⚽ GOOOOOL! Ralou FC akhirnya memecah kebuntuan!"
        : "⚽ GOL! Lawan akhirnya memecah kebuntuan!",
      x: 50,
      y: forcedSide === "home" ? 4 : 96,
    });
  }

  events.sort((a, b) => a.minute - b.minute || a.id.localeCompare(b.id));

  let result = "DRAW";
  if (homeGoals > awayGoals) result = "WIN";
  if (homeGoals < awayGoals) result = "LOSS";

  return {
    userGoals: homeGoals,
    oppGoals: awayGoals,
    result,
    events,
  };
}

export default function FootballGame({ backToGameHub }) {
  const [playerKey] = useState(getPlayerKey);
  const localInitial = useMemo(() => readLocalSave(playerKey), [playerKey]);

  const [coins, setCoins] = useState(
    typeof localInitial?.coins === "number" ? localInitial.coins : INITIAL_COINS
  );
  const [results, setResults] = useState([]);
  const [revealed, setRevealed] = useState(false);
  const [message, setMessage] = useState("");
  const [collection, setCollection] = useState(
    Array.isArray(localInitial?.collection) ? localInitial.collection : []
  );
  const [squad, setSquad] = useState(normalizeSquad(localInitial?.squad));
  const [selectedTab, setSelectedTab] = useState("gacha");
  const [loading, setLoading] = useState(true);
  const [formation, setFormation] = useState(
    localInitial?.formation && FORMATIONS[localInitial.formation]
      ? localInitial.formation
      : "4-3-3"
  );
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [dailyClaimDate, setDailyClaimDate] = useState(
    localInitial?.dailyClaimDate || null
  );
  const [history, setHistory] = useState(
    normalizeHistory(localInitial?.history)
  );
  const [match, setMatch] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isHalftime, setIsHalftime] = useState(false);
  const matchTimerRef = useRef(null);

  const squadCardIds = Object.values(squad);

  const activeSquadCardIds = useMemo(() => {
    const activeSlotIds = new Set(
      (FORMATIONS[formation] || []).map((slot) => slot.id)
    );

    return Object.entries(squad)
      .filter(([slotId]) => activeSlotIds.has(slotId))
      .map(([, cardId]) => cardId);
  }, [squad, formation]);

  const collectionCounts = useMemo(() => {
    const counts = {};
    for (const id of collection) {
      counts[id] = (counts[id] || 0) + 1;
    }
    return counts;
  }, [collection]);

  function getSquadUsageCount(cardId) {
    return squadCardIds.filter((id) => id === cardId).length;
  }

  const activeSquad = useMemo(() => {
    const activeSlotIds = new Set(
      (FORMATIONS[formation] || []).map((slot) => slot.id)
    );

    return Object.fromEntries(
      Object.entries(squad).filter(([slotId]) => activeSlotIds.has(slotId))
    );
  }, [squad, formation]);

  const teamOverall = useMemo(() => getTeamOverall(activeSquad), [activeSquad]);
  const teamStrength = useMemo(() => getSquadStrength(activeSquad), [activeSquad]);

  const selectedSlotData = useMemo(() => {
    if (!selectedSlot) return null;
    return FORMATIONS[formation]?.find((slot) => slot.id === selectedSlot) || null;
  }, [selectedSlot, formation]);

  const selectableCards = useMemo(() => {
    if (!selectedSlotData) return [];

    const slotPosition = selectedSlotData.label;
    const cards = [];

    for (const cardId of Object.keys(collectionCounts)) {
      const card = getCardById(cardId);
      if (!card) continue;

      if (!isCompatiblePosition(card, slotPosition)) continue;

      const owned = collectionCounts[cardId] || 0;
      const used = getSquadUsageCount(cardId);

      if (used >= owned) continue;
      cards.push(card);
    }

    return cards.sort((a, b) => b.overall - a.overall);
  }, [selectedSlotData, collectionCounts, squadCardIds]);

  useEffect(() => {
    const local = readLocalSave(playerKey);
    if (local) {
      setCoins(typeof local.coins === "number" ? local.coins : INITIAL_COINS);
      setCollection(Array.isArray(local.collection) ? local.collection : []);
      setSquad(normalizeSquad(local.squad));
      setFormation(
        local.formation && FORMATIONS[local.formation]
          ? local.formation
          : "4-3-3"
      );
      setDailyClaimDate(local.dailyClaimDate || null);
      setHistory(normalizeHistory(local.history));
    }

    const playerRef = ref(db, `footballPlayers/${playerKey}`);

    const unsubscribe = onValue(
      playerRef,
      (snapshot) => {
        const data = snapshot.val();

        if (data) {
          setCoins(typeof data.coins === "number" ? data.coins : INITIAL_COINS);
          setCollection(Array.isArray(data.collection) ? data.collection : []);
          setSquad(normalizeSquad(data.squad));
          setFormation(
            data.formation && FORMATIONS[data.formation]
              ? data.formation
              : "4-3-3"
          );
          setDailyClaimDate(data.dailyClaimDate || null);
          setHistory(normalizeHistory(data.history));
        }

        setLoading(false);
      },
      (error) => {
        console.error("Football Firebase error:", error);
        setMessage(
          "Mode offline aktif. Data tetap disimpan di browser. Firebase Rules bisa dibetulkan nanti."
        );
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [playerKey]);

  function saveData(
    nextCoins,
    nextCollection,
    nextSquad,
    nextFormation = formation,
    nextDailyClaimDate = dailyClaimDate,
    nextHistory = history
  ) {
    const payload = {
      coins: nextCoins,
      collection: nextCollection,
      squad: nextSquad,
      formation: nextFormation,
      dailyClaimDate: nextDailyClaimDate,
      history: nextHistory.slice(0, 20),
      updatedAt: Date.now(),
    };

    try {
      localStorage.setItem(getLocalKey(playerKey), JSON.stringify(payload));
    } catch (error) {
      console.error("Football local save error:", error);
    }

    set(ref(db, `footballPlayers/${playerKey}`), payload).catch((error) => {
      console.error("Football Firebase save error:", error);
    });
  }

  function claimDailyCoins() {
    const today = getTodayKey();

    if (dailyClaimDate === today) {
      setMessage("Bonus harian sudah diambil hari ini.");
      return;
    }

    const isFirstDay = !dailyClaimDate;
    const reward = isFirstDay ? FIRST_DAY_COINS : DAILY_COINS;
    const nextCoins = coins + reward;

    setCoins(nextCoins);
    setDailyClaimDate(today);
    saveData(nextCoins, collection, squad, formation, today, history);

    setMessage(
      isFirstDay
        ? "+400 🪙 First Day Bonus berhasil diambil!"
        : "+200 🪙 bonus harian berhasil diambil!"
    );
  }

  function doSingleGacha() {
    if (coins < SINGLE_COST) {
      setMessage("Coin lu nggak cukup.");
      return;
    }

    const card = drawCard();

    if (!card) {
      setMessage("Belum ada kartu untuk rarity tersebut.");
      return;
    }

    const nextCoins = coins - SINGLE_COST;
    const nextCollection = [...collection, card.id];

    setCoins(nextCoins);
    setCollection(nextCollection);
    setResults([card]);
    setRevealed(false);

    saveData(nextCoins, nextCollection, squad);

    setMessage(`${card.name} berhasil masuk Collection!`);
  }

  function doTenGacha() {
    if (coins < TEN_COST) {
      setMessage("Coin lu nggak cukup.");
      return;
    }

    const cards = tenGacha();
    const cardIds = cards.map((card) => card.id);
    const nextCoins = coins - TEN_COST;
    const nextCollection = [...collection, ...cardIds];

    setCoins(nextCoins);
    setCollection(nextCollection);
    setResults(cards);
    setRevealed(false);

    saveData(nextCoins, nextCollection, squad);

    setMessage(`${cards.length} kartu berhasil masuk Collection!`);
  }

  function revealCards() {
    setRevealed(true);
  }

  function putPlayerIntoSlot(cardId) {
    if (!selectedSlot) return;

    const card = getCardById(cardId);
    if (!card) return;

    const slot = FORMATIONS[formation]?.find((item) => item.id === selectedSlot);
    if (!slot) return;

    if (!isCompatiblePosition(card, slot.label)) {
      setMessage(`${card.name} tidak cocok untuk posisi ${slot.label}.`);
      return;
    }

    const oldCardId = squad[selectedSlot];

    if (oldCardId === cardId) {
      setMessage(`${card.name} sudah berada di posisi ini.`);
      setSelectedSlot(null);
      return;
    }

    const usedElsewhere = Object.entries(squad).filter(
      ([slotId, id]) => id === cardId && slotId !== selectedSlot
    ).length;

    const owned = collectionCounts[cardId] || 0;

    if (usedElsewhere >= owned) {
      setMessage("Jumlah kartu yang lu punya tidak cukup untuk memakai copy ini lagi.");
      return;
    }

    const nextSquad = {
      ...squad,
      [selectedSlot]: cardId,
    };

    setSquad(nextSquad);
    saveData(coins, collection, nextSquad);

    setSelectedSlot(null);

    if (oldCardId) {
      const oldCard = getCardById(oldCardId);
      setMessage(
        `${card.name} menggantikan ${oldCard?.name || "pemain lama"} di ${slot.label}.`
      );
    } else {
      setMessage(`${card.name} masuk ke posisi ${slot.label}!`);
    }
  }

  function removeFromSlot(slotId) {
    if (!slotId || !squad[slotId]) return;

    const removed = getCardById(squad[slotId]);
    const nextSquad = { ...squad };
    delete nextSquad[slotId];

    setSquad(nextSquad);
    saveData(coins, collection, nextSquad);
    setSelectedSlot(null);

    setMessage(
      `${removed?.name || "Pemain"} dikeluarkan dari squad.`
    );
  }

  function changeFormation(nextFormation) {
    if (!FORMATIONS[nextFormation]) return;

    const nextSlots = FORMATIONS[nextFormation];
    const currentPlayers = Object.values(squad)
      .map((cardId) => getCardById(cardId))
      .filter(Boolean);

    // Jangan buang 11 pemain ketika formasi berubah.
    // Kita susun ulang pemain ke slot formasi baru: utamakan posisi yang cocok,
    // lalu gunakan slot tersisa sebagai fallback supaya jumlah pemain tetap 11.
    const nextSquad = {};
    const usedCardIndexes = new Set();

    // 1. GK selalu dicari ke slot GK.
    const gkSlot = nextSlots.find((slot) => slot.label === "GK");
    const gkIndex = currentPlayers.findIndex((card) => card.position === "GK");
    if (gkSlot && gkIndex >= 0) {
      nextSquad[gkSlot.id] = currentPlayers[gkIndex].id;
      usedCardIndexes.add(gkIndex);
    }

    // 2. Isi slot lain dengan pemain yang posisi aslinya paling cocok.
    for (const slot of nextSlots) {
      if (nextSquad[slot.id]) continue;

      let bestIndex = -1;

      for (let i = 0; i < currentPlayers.length; i++) {
        if (usedCardIndexes.has(i)) continue;
        const card = currentPlayers[i];

        if (isCompatiblePosition(card, slot.label)) {
          bestIndex = i;
          break;
        }
      }

      if (bestIndex >= 0) {
        nextSquad[slot.id] = currentPlayers[bestIndex].id;
        usedCardIndexes.add(bestIndex);
      }
    }

    // 3. Kalau formasi membutuhkan bentuk yang berbeda (mis. 5-3-2),
    // pemain yang tersisa tetap dipasang ke slot kosong daripada menghilang.
    // Ini memang bisa membuat beberapa pemain berada di luar posisi aslinya,
    // tetapi user tetap memiliki 11 pemain dan bisa melakukan pergantian saat halftime.
    for (let i = 0; i < currentPlayers.length; i++) {
      if (usedCardIndexes.has(i)) continue;

      const emptySlot = nextSlots.find((slot) => !nextSquad[slot.id]);
      if (!emptySlot) break;

      nextSquad[emptySlot.id] = currentPlayers[i].id;
      usedCardIndexes.add(i);
    }

    setFormation(nextFormation);
    setSquad(nextSquad);
    setSelectedSlot(null);
    saveData(coins, collection, nextSquad, nextFormation);

    const assigned = Object.keys(nextSquad).length;
    setMessage(
      assigned === MAX_SQUAD
        ? `Formasi diganti ke ${nextFormation}. 11 pemain tetap dipertahankan.`
        : `Formasi diganti ke ${nextFormation}. ${assigned}/${MAX_SQUAD} pemain terpasang.`
    );
  }

  function clearSquad() {
    setSquad({});
    setSelectedSlot(null);
    saveData(coins, collection, {}, formation);
    setMessage("Semua pemain dikeluarkan dari squad.");
  }

  function addFromCollection(cardId) {
    const card = getCardById(cardId);
    if (!card) return;

    const availableSlot = FORMATIONS[formation].find(
      (slot) =>
        !squad[slot.id] &&
        isCompatiblePosition(card, slot.label)
    );

    if (!availableSlot) {
      setSelectedTab("squad");
      setMessage(
        `Tidak ada slot kosong yang cocok untuk ${card.name} di formasi ${formation}.`
      );
      return;
    }

    setSelectedTab("squad");
    setSelectedSlot(availableSlot.id);
    setMessage(
      `Pilih ${card.name} untuk dipasang di ${availableSlot.label}.`
    );
  }

  function finishMatch(simulation, opponent, finalMinute) {
    const reward = simulation.result === "WIN" ? 80 : simulation.result === "DRAW" ? 45 : 25;
    const nextCoins = coins + reward;
    const record = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      date: new Date().toLocaleString("id-ID"),
      opponent: opponent.name,
      opponentOverall: opponent.overall,
      userOverall: teamOverall,
      userGoals: simulation.userGoals,
      oppGoals: simulation.oppGoals,
      result: simulation.result,
      reward,
    };
    const nextHistory = [record, ...history].slice(0, 20);

    setCoins(nextCoins);
    setHistory(nextHistory);
    setMatch((current) => ({
      ...current,
      result: simulation.result,
      events: simulation.events,
      userGoals: simulation.userGoals,
      oppGoals: simulation.oppGoals,
      reward,
      currentMinute: finalMinute,
      totalMinutes: 90,
    }));
    setIsPlaying(false);
    setIsHalftime(false);
    saveData(nextCoins, collection, squad, formation, dailyClaimDate, nextHistory);
    setMessage(
      simulation.result === "WIN"
        ? `MENANG! +${reward} 🪙`
        : simulation.result === "DRAW"
        ? `SERI! +${reward} 🪙`
        : `KALAH. Tetap dapat +${reward} 🪙`
    );
  }

  function runMatchClock(startMinute = 0, suppliedMatch = null) {
    const activeMatch = suppliedMatch || match;
    if (!activeMatch?.simulation) return;
    if (matchTimerRef.current) clearInterval(matchTimerRef.current);

    const simulation = activeMatch.simulation;
    const opponent = activeMatch.opponent;
    let minute = startMinute;

    setIsPlaying(true);
    setIsHalftime(false);

    matchTimerRef.current = setInterval(() => {
      minute += 1;
      const visibleEvents = simulation.events.filter((event) => event.minute <= minute);
      const userGoals = visibleEvents.filter((event) => event.side === "home" && event.type === "goal").length;
      const oppGoals = visibleEvents.filter((event) => event.side === "away" && event.type === "goal").length;

      setMatch((current) => ({ ...current, currentMinute: minute, events: visibleEvents, userGoals, oppGoals }));

      if (minute === 45) {
        clearInterval(matchTimerRef.current);
        matchTimerRef.current = null;
        setIsPlaying(false);
        setIsHalftime(true);
        setMessage("⏸️ Babak pertama selesai. Waktunya atur strategi!");
        return;
      }

      if (minute >= 90) {
        clearInterval(matchTimerRef.current);
        matchTimerRef.current = null;
        finishMatch(simulation, opponent, 90);
      }
    }, 1000);
  }

  function playMatch() {
    const activeSlotIds = new Set((FORMATIONS[formation] || []).map((slot) => slot.id));
    const activeSquad = Object.fromEntries(Object.entries(squad).filter(([slotId]) => activeSlotIds.has(slotId)));
    const activeSquadCardIds = Object.values(activeSquad);

    if (activeSquadCardIds.length !== MAX_SQUAD) {
      setSelectedTab("squad");
      setMessage(`Isi 11 pemain di formasi ${formation} dulu sebelum pertandingan.`);
      return;
    }
    if (!activeSquad.GK) {
      setSelectedTab("squad");
      setMessage("Squad wajib punya goalkeeper.");
      return;
    }

    const opponent = makeOpponent(teamOverall);
    const simulation = simulateMatch(teamOverall, opponent.overall);

    setMatch({ opponent, result: null, events: [], userGoals: 0, oppGoals: 0, currentMinute: 0, totalMinutes: 90, simulation });
    setIsPlaying(false);
    setIsHalftime(false);
    setSelectedTab("match");
    setTimeout(() => runMatchClock(0, { opponent, simulation }), 50);
  }


  useEffect(() => () => {
    if (matchTimerRef.current) clearInterval(matchTimerRef.current);
  }, []);

  if (loading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: BG,
          color: CREAM,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 18,
          fontWeight: 800,
        }}
      >
        Memuat Football...
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        background: BG,
        color: CREAM,
        padding: 24,
        boxSizing: "border-box",
        fontFamily: "Arial, Helvetica, sans-serif",
      }}
    >
      <div style={{ maxWidth: 1200, margin: "0 auto" }}>
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 16,
            marginBottom: 20,
            flexWrap: "wrap",
          }}
        >
          <div>
            <div
              style={{
                color: GOLD,
                fontSize: 13,
                fontWeight: 900,
                letterSpacing: 3,
              }}
            >
              RALOU GAME HUB
            </div>
            <h1 style={{ margin: "5px 0 0", fontSize: 32 }}>
              Football
            </h1>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <div
              style={{
                background: PANEL,
                border: `1px solid ${GOLD}`,
                borderRadius: 12,
                padding: "10px 16px",
                fontWeight: 900,
              }}
            >
              🪙 {coins}
            </div>

            <button
              onClick={claimDailyCoins}
              style={buttonStyle()}
              disabled={dailyClaimDate === getTodayKey()}
            >
              {dailyClaimDate === getTodayKey()
                ? "✓ Claimed Today"
                : dailyClaimDate
                ? "🎁 +200 Daily"
                : "🎁 +400 First Day"}
            </button>

            <button onClick={backToGameHub} style={buttonStyle()}>
              ← Game Hub
            </button>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: 8,
            marginBottom: 20,
            flexWrap: "wrap",
          }}
        >
          <TabButton
            active={selectedTab === "gacha"}
            onClick={() => setSelectedTab("gacha")}
          >
            🎴 Gacha
          </TabButton>

          <TabButton
            active={selectedTab === "collection"}
            onClick={() => setSelectedTab("collection")}
          >
            📚 Collection ({collection.length})
          </TabButton>

          <TabButton
            active={selectedTab === "squad"}
            onClick={() => setSelectedTab("squad")}
          >
            ⚽ My Squad ({activeSquadCardIds.length}/11)
          </TabButton>

          <TabButton
            active={selectedTab === "match"}
            onClick={() => setSelectedTab("match")}
          >
            🏟️ Match
          </TabButton>

          <TabButton
            active={selectedTab === "history"}
            onClick={() => setSelectedTab("history")}
          >
            📜 History ({history.length})
          </TabButton>
        </div>

        {message && (
          <div
            style={{
              marginBottom: 16,
              padding: "12px 15px",
              background: PANEL,
              border: "1px solid rgba(201,162,39,0.35)",
              borderRadius: 12,
              color: CREAM,
              fontWeight: 700,
            }}
          >
            {message}
          </div>
        )}

        {selectedTab === "gacha" && (
          <GachaPanel
            results={results}
            revealed={revealed}
            revealCards={revealCards}
            doSingleGacha={doSingleGacha}
            doTenGacha={doTenGacha}
          />
        )}

        {selectedTab === "collection" && (
          <CollectionPanel
            collection={collection}
            collectionCounts={collectionCounts}
            onAddToSquad={addFromCollection}
          />
        )}

        {selectedTab === "squad" && (
          <SquadBuilder
            formation={formation}
            setFormation={changeFormation}
            squad={squad}
            selectedSlot={selectedSlot}
            setSelectedSlot={setSelectedSlot}
            removeFromSlot={removeFromSlot}
            clearSquad={clearSquad}
            selectableCards={selectableCards}
            putPlayerIntoSlot={putPlayerIntoSlot}
            teamOverall={teamOverall}
            teamStrength={teamStrength}
            playMatch={playMatch}
          />
        )}

        {selectedTab === "match" && (
          <MatchPanel
            match={match}
            isPlaying={isPlaying}
            isHalftime={isHalftime}
            teamOverall={teamOverall}
            playMatch={playMatch}
            resumeMatch={() => runMatchClock(45)}
            squad={activeSquad}
            formation={formation}
            collection={collection}
            collectionCounts={collectionCounts}
            squadReady={activeSquadCardIds.length === 11 && !!activeSquad.GK}
            changeFormation={changeFormation}
            substitutePlayer={(slotId, cardId) => {
              const slot = FORMATIONS[formation]?.find((item) => item.id === slotId);
              const card = getCardById(cardId);
              if (!slot || !card) return;
              if (!isCompatiblePosition(card, slot.label)) {
                setMessage(`${card.name} tidak cocok untuk posisi ${slot.label}.`);
                return;
              }
              const usedElsewhere = Object.entries(squad).filter(([otherSlotId, id]) => otherSlotId !== slotId && id === cardId).length;
              const owned = collectionCounts[cardId] || 0;
              if (usedElsewhere >= owned) {
                setMessage("Jumlah kartu yang lu punya tidak cukup untuk memakai copy ini lagi.");
                return;
              }
              const nextSquad = { ...squad, [slotId]: cardId };
              setSquad(nextSquad);
              saveData(coins, collection, nextSquad, formation, dailyClaimDate, history);
              setMessage(`${card.name} masuk menggantikan pemain di ${slot.label}.`);
            }}
          />
        )}

        {selectedTab === "history" && (
          <HistoryPanel history={history} />
        )}
      </div>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "11px 17px",
        borderRadius: 11,
        border: active
          ? `1px solid ${GOLD}`
          : "1px solid rgba(245,239,224,0.12)",
        background: active
          ? "rgba(201,162,39,0.15)"
          : PANEL,
        color: active ? GOLD : CREAM,
        fontWeight: 900,
        cursor: "pointer",
      }}
    >
      {children}
    </button>
  );
}

function GachaPanel({
  results,
  revealed,
  revealCards,
  doSingleGacha,
  doTenGacha,
}) {
  return (
    <div
      style={{
        background: PANEL,
        borderRadius: 20,
        border: "1px solid rgba(201,162,39,0.3)",
        padding: 24,
      }}
    >
      <h2 style={{ marginTop: 0, color: GOLD }}>Player Gacha</h2>

      <p style={{ opacity: 0.75 }}>
        Kumpulkan pemain, susun squad, lalu bawa mereka ke pertandingan otomatis.
      </p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))",
          gap: 12,
          marginBottom: 25,
        }}
      >
        <button onClick={doSingleGacha} style={buttonStyle()}>
          🎴 1x Gacha — 20 🪙
        </button>

        <button
          onClick={doTenGacha}
          style={{
            ...buttonStyle(),
            background: "rgba(201,162,39,0.16)",
          }}
        >
          🎴 10x Gacha — 200 🪙
        </button>
      </div>

      <div
        style={{
          background: PANEL_SOFT,
          borderRadius: 14,
          padding: 14,
          marginBottom: 20,
          fontSize: 13,
          lineHeight: 1.7,
        }}
      >
        <strong style={{ color: GOLD }}>Gacha odds:</strong>{" "}
        Standard 60% · Rare 25% · Epic 12% · Legendary 3%
      </div>

      {results.length > 0 && (
        <>
          <button
            onClick={revealCards}
            style={{ ...buttonStyle(), marginBottom: 20 }}
          >
            {revealed ? "Cards Revealed" : "Reveal Cards"}
          </button>

          <div
            style={{
              display: "flex",
              gap: 18,
              flexWrap: "wrap",
              justifyContent: "center",
            }}
          >
            {results.map((card, index) => (
              <PlayerCard
                key={`${card.id}-${index}`}
                card={card}
                revealed={revealed}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function CollectionPanel({
  collection,
  collectionCounts,
  onAddToSquad,
}) {
  const uniqueCards = Object.keys(collectionCounts);

  if (uniqueCards.length === 0) {
    return (
      <div style={emptyStyle()}>
        Belum ada pemain.
        <br />
        Buka Gacha dulu.
      </div>
    );
  }

  return (
    <div>
      <div style={{ marginBottom: 18, opacity: 0.75 }}>
        Total kartu: <strong>{collection.length}</strong>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
          gap: 18,
        }}
      >
        {uniqueCards.map((cardId) => {
          const card = getCardById(cardId);
          if (!card) return null;

          return (
            <CollectionCard
              key={cardId}
              card={card}
              count={collectionCounts[cardId]}
              onAdd={() => onAddToSquad(cardId)}
            />
          );
        })}
      </div>
    </div>
  );
}

function CollectionCard({ card, count, onAdd }) {
  return (
    <div
      style={{
        background: PANEL,
        borderRadius: 18,
        padding: 12,
        border: "1px solid rgba(245,239,224,0.1)",
      }}
    >
      <PlayerCard card={card} />

      <button
        onClick={onAdd}
        style={{
          width: "100%",
          marginTop: 12,
          padding: 11,
          borderRadius: 10,
          border: `1px solid ${GOLD}`,
          background: "rgba(201,162,39,0.12)",
          color: CREAM,
          fontWeight: 900,
          cursor: "pointer",
        }}
      >
        + Masukkan ke Squad
      </button>

      <div
        style={{
          textAlign: "center",
          marginTop: 8,
          fontSize: 12,
          opacity: 0.7,
        }}
      >
        Owned ×{count}
      </div>
    </div>
  );
}

function SquadBuilder({
  formation,
  setFormation,
  squad,
  selectedSlot,
  setSelectedSlot,
  removeFromSlot,
  clearSquad,
  selectableCards,
  putPlayerIntoSlot,
  teamOverall,
  teamStrength,
  playMatch,
}) {
  const slots = FORMATIONS[formation] || FORMATIONS["4-3-3"];

  return (
    <div>
      <div
        style={{
          background: PANEL,
          borderRadius: 18,
          padding: 18,
          marginBottom: 18,
          border: "1px solid rgba(201,162,39,0.3)",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 15,
          flexWrap: "wrap",
        }}
      >
        <div>
          <div
            style={{
              color: GOLD,
              fontSize: 12,
              fontWeight: 900,
              letterSpacing: 2,
            }}
          >
            MY SQUAD
          </div>

          <div style={{ fontSize: 26, fontWeight: 900, marginTop: 4 }}>
            {slots.filter((slot) => squad[slot.id]).length}/11
          </div>
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            flexWrap: "wrap",
          }}
        >
          <StatBox label="OVR" value={teamOverall || "-"} />
          <StatBox label="POWER" value={teamStrength || "-"} />

          <span style={{ fontWeight: 800, opacity: 0.75 }}>
            Formation
          </span>

          <select
            value={formation}
            onChange={(e) => setFormation(e.target.value)}
            style={{
              background: PANEL_SOFT,
              color: CREAM,
              border: `1px solid ${GOLD}`,
              borderRadius: 10,
              padding: "10px 14px",
              fontWeight: 900,
            }}
          >
            {Object.keys(FORMATIONS).map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>

          <button
            onClick={playMatch}
            style={{
              ...buttonStyle(),
              background: "rgba(201,162,39,0.2)",
            }}
          >
            🏟️ Play Match
          </button>

          <button
            onClick={clearSquad}
            style={{
              ...buttonStyle(),
              borderColor: "rgba(255,100,100,0.4)",
            }}
          >
            Clear Squad
          </button>
        </div>
      </div>

      <div style={{ display: "flex", justifyContent: "center" }}>
        <div
          style={{
            position: "relative",
            width: "min(900px, 100%)",
            aspectRatio: "16 / 10",
            borderRadius: 25,
            overflow: "hidden",
            border: "3px solid rgba(245,239,224,0.25)",
            background:
              "linear-gradient(90deg, #17351f, #20552e, #17351f)",
            boxShadow: "0 25px 60px rgba(0,0,0,0.45)",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              background:
                "repeating-linear-gradient(90deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 55px, transparent 55px, transparent 110px)",
            }}
          />

          <div
            style={{
              position: "absolute",
              left: 0,
              right: 0,
              top: "50%",
              borderTop: "2px solid rgba(255,255,255,0.45)",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: 105,
              height: 105,
              border: "2px solid rgba(255,255,255,0.45)",
              borderRadius: "50%",
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: 7,
              height: 7,
              background: "rgba(255,255,255,0.7)",
              borderRadius: "50%",
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: "35%",
              height: "18%",
              left: "32.5%",
              top: 0,
              border: "2px solid rgba(255,255,255,0.4)",
              borderTop: "none",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: "35%",
              height: "18%",
              left: "32.5%",
              bottom: 0,
              border: "2px solid rgba(255,255,255,0.4)",
              borderBottom: "none",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: "18%",
              height: 5,
              left: "41%",
              top: 0,
              background: "rgba(255,255,255,0.65)",
            }}
          />

          <div
            style={{
              position: "absolute",
              width: "18%",
              height: 5,
              left: "41%",
              bottom: 0,
              background: "rgba(255,255,255,0.65)",
            }}
          />

          {slots.map((slot) => {
            const cardId = squad[slot.id];
            const card = cardId ? getCardById(cardId) : null;
            const active = selectedSlot === slot.id;

            return (
              <div
                key={slot.id}
                style={{
                  position: "absolute",
                  left: `${slot.x}%`,
                  top: `${slot.y}%`,
                  transform: "translate(-50%, -50%)",
                  zIndex: active ? 10 : 5,
                }}
              >
                <PitchPlayer
                  card={card}
                  label={slot.label}
                  active={active}
                  onClick={() => setSelectedSlot(slot.id)}
                />
              </div>
            );
          })}
        </div>
      </div>

      {selectedSlot && (
        <div
          style={{
            marginTop: 18,
            background: PANEL,
            borderRadius: 18,
            padding: 20,
            border: "1px solid rgba(201,162,39,0.35)",
          }}
        >
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 15,
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <div>
              <div
                style={{
                  color: GOLD,
                  fontSize: 12,
                  fontWeight: 900,
                  letterSpacing: 2,
                }}
              >
                SELECT PLAYER
              </div>

              <div
                style={{
                  fontSize: 22,
                  fontWeight: 900,
                  marginTop: 4,
                }}
              >
                Posisi:{" "}
                {FORMATIONS[formation]?.find(
                  (slot) => slot.id === selectedSlot
                )?.label || selectedSlot}
              </div>
            </div>

            <button
              onClick={() => setSelectedSlot(null)}
              style={buttonStyle()}
            >
              Tutup
            </button>
          </div>

          {squad[selectedSlot] && (
            <button
              onClick={() => removeFromSlot(selectedSlot)}
              style={{
                width: "100%",
                marginBottom: 16,
                padding: 11,
                borderRadius: 10,
                border: "1px solid rgba(255,100,100,0.4)",
                background: "rgba(120,30,30,0.18)",
                color: CREAM,
                fontWeight: 900,
                cursor: "pointer",
              }}
            >
              🗑️ Keluarkan Pemain
            </button>
          )}

          {selectableCards.length === 0 ? (
            <div
              style={{
                textAlign: "center",
                padding: 30,
                opacity: 0.7,
              }}
            >
              Belum ada kartu yang cocok untuk posisi ini.
            </div>
          ) : (
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "repeat(auto-fill, minmax(230px, 1fr))",
                gap: 15,
              }}
            >
              {selectableCards.map((card) => (
                <div
                  key={card.id}
                  style={{
                    background: PANEL_SOFT,
                    borderRadius: 16,
                    padding: 10,
                    border: "1px solid rgba(245,239,224,0.1)",
                  }}
                >
                  <PlayerCard card={card} />

                  <button
                    onClick={() => putPlayerIntoSlot(card.id)}
                    style={{
                      width: "100%",
                      marginTop: 10,
                      padding: 11,
                      borderRadius: 10,
                      border: `1px solid ${GOLD}`,
                      background: "rgba(201,162,39,0.13)",
                      color: CREAM,
                      fontWeight: 900,
                      cursor: "pointer",
                    }}
                  >
                    Pasang di{" "}
                    {FORMATIONS[formation]?.find(
                      (slot) => slot.id === selectedSlot
                    )?.label || selectedSlot}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function MatchPanel({
  match,
  isPlaying,
  isHalftime,
  teamOverall,
  squadReady,
  playMatch,
  resumeMatch,
  squad,
  formation,
  collection,
  collectionCounts,
  changeFormation,
  substitutePlayer,
}) {
  if (!match) {
    return (
      <div
        style={{
          background: PANEL,
          borderRadius: 20,
          padding: 30,
          border: "1px solid rgba(201,162,39,0.3)",
          textAlign: "center",
        }}
      >
        <div style={{ color: GOLD, fontSize: 13, fontWeight: 900, letterSpacing: 3 }}>
          AUTO MATCH
        </div>
        <h2 style={{ marginBottom: 8 }}>Belum ada pertandingan</h2>
        <p style={{ opacity: 0.7 }}>
          Isi 11 pemain di My Squad lalu mulai pertandingan.
        </p>
        <button
          onClick={playMatch}
          disabled={!squadReady}
          style={{
            ...buttonStyle(),
            opacity: squadReady ? 1 : 0.45,
          }}
        >
          🏟️ Mulai Match
        </button>
      </div>
    );
  }

  const finished = !isPlaying && match.result;
  const activeSquad = Object.fromEntries(
    Object.entries(squad).filter(([slotId]) =>
      (FORMATIONS[formation] || []).some((slot) => slot.id === slotId)
    )
  );
  const activeSquadReady = Object.values(activeSquad).length === 11 && !!activeSquad.GK;

  return (
    <div>
      <div
        style={{
          background: PANEL,
          borderRadius: 20,
          padding: 20,
          border: "1px solid rgba(201,162,39,0.3)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 12,
            flexWrap: "wrap",
            marginBottom: 15,
          }}
        >
          <div>
            <div style={{ color: GOLD, fontSize: 12, fontWeight: 900, letterSpacing: 3 }}>
              {isHalftime ? "HALF TIME" : isPlaying ? "LIVE MATCH" : match.result ? "FULL TIME" : "MATCH"}
            </div>
            <div style={{ marginTop: 4, fontSize: 13, opacity: 0.65 }}>
              11 vs 11 · {formation}
            </div>
          </div>

          <div
            style={{
              padding: "8px 15px",
              borderRadius: 12,
              background: PANEL_SOFT,
              border: `1px solid ${isPlaying ? GOLD : "rgba(245,239,224,0.12)"}`,
              fontWeight: 900,
              fontSize: 20,
              color: isPlaying ? GOLD : CREAM,
            }}
          >
            {`${match.currentMinute || 0}'`}
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            alignItems: "center",
            gap: 18,
            marginBottom: 18,
          }}
        >
          <div>
            <div style={{ fontSize: 20, fontWeight: 900 }}>RALOU FC</div>
            <div style={{ opacity: 0.65, marginTop: 4 }}>OVR {teamOverall}</div>
          </div>

          <div
            style={{
              fontSize: 38,
              fontWeight: 900,
              color: finished
                ? match.result === "WIN"
                  ? "#69d27c"
                  : match.result === "LOSS"
                  ? "#ff7777"
                  : GOLD
                : CREAM,
            }}
          >
            {match.userGoals} - {match.oppGoals}
          </div>

          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 20, fontWeight: 900 }}>{match.opponent.name}</div>
            <div style={{ opacity: 0.65, marginTop: 4 }}>OVR {match.opponent.overall}</div>
          </div>
        </div>

        <MatchBoard
          match={match}
          isPlaying={isPlaying}
          squad={activeSquad}
          formation={formation}
        />

        {isHalftime && (
          <HalftimePanel
            match={match}
            squad={squad}
            formation={formation}
            collection={collection}
            collectionCounts={collectionCounts}
            squadReady={activeSquadReady}
            changeFormation={changeFormation}
            substitutePlayer={substitutePlayer}
            resumeMatch={resumeMatch}
          />
        )}

        {finished && (
          <div
            style={{
              marginTop: 20,
              textAlign: "center",
              fontSize: 24,
              fontWeight: 900,
              color:
                match.result === "WIN"
                  ? "#69d27c"
                  : match.result === "LOSS"
                  ? "#ff7777"
                  : GOLD,
            }}
          >
            {match.result === "WIN" ? "🏆 MENANG" : match.result === "LOSS" ? "💥 KALAH" : "🤝 SERI"}
          </div>
        )}

        {finished && (
          <div style={{ marginTop: 8, textAlign: "center", opacity: 0.8, fontWeight: 800 }}>
            Reward: +{match.reward} 🪙
          </div>
        )}

        <div
          style={{
            marginTop: 20,
            textAlign: "left",
            background: PANEL_SOFT,
            borderRadius: 14,
            padding: 15,
            maxHeight: 230,
            overflowY: "auto",
          }}
        >
          {match.events.length === 0 ? (
            <div style={{ opacity: 0.65, textAlign: "center", padding: 15 }}>
              Kick-off! Pemain mulai bergerak...
            </div>
          ) : (
            match.events.map((event, index) => (
              <div
                key={`${event.minute}-${index}`}
                style={{
                  padding: "8px 4px",
                  borderBottom:
                    index === match.events.length - 1
                      ? "none"
                      : "1px solid rgba(245,239,224,0.07)",
                  fontSize: 14,
                }}
              >
                <strong style={{ color: GOLD }}>{event.minute}'</strong>{" "}
                {event.text}
              </div>
            ))
          )}
        </div>

        {!isPlaying && !isHalftime && (
          <button
            onClick={playMatch}
            disabled={!squadReady}
            style={{
              ...buttonStyle(),
              width: "100%",
              marginTop: 18,
              opacity: squadReady ? 1 : 0.45,
            }}
          >
            🔄 Main Lagi
          </button>
        )}
      </div>
    </div>
  );
}

function HalftimePanel({ match, squad, formation, collection, collectionCounts, squadReady, changeFormation, substitutePlayer, resumeMatch }) {
  const [selectedSlot, setSelectedSlot] = useState(null);
  const slots = FORMATIONS[formation] || FORMATIONS["4-3-3"];
  const uniqueCards = [];
  const seen = new Set();
  for (const cardId of collection) {
    if (seen.has(cardId)) continue;
    const card = getCardById(cardId);
    if (!card) continue;
    seen.add(cardId);
    uniqueCards.push(card);
  }
  const selectedSlotData = slots.find((slot) => slot.id === selectedSlot);
  const currentCard = selectedSlot ? getCardById(squad[selectedSlot]) : null;
  const candidates = selectedSlotData ? uniqueCards.filter((card) => {
    if (!isCompatiblePosition(card, selectedSlotData.label)) return false;
    const usedElsewhere = Object.entries(squad).filter(([slotId, id]) => slotId !== selectedSlot && id === card.id).length;
    return usedElsewhere < (collectionCounts[card.id] || 0);
  }) : [];

  return (
    <div style={{ marginTop: 18, padding: 18, borderRadius: 16, background: "linear-gradient(145deg, #302818, #1c1712)", border: `1px solid ${GOLD}` }}>
      <div style={{ textAlign: "center", marginBottom: 15 }}>
        <div style={{ color: GOLD, fontSize: 12, fontWeight: 900, letterSpacing: 3 }}>⏸️ HALF TIME</div>
        <div style={{ fontSize: 22, fontWeight: 1000, marginTop: 5 }}>{match.userGoals} - {match.oppGoals}</div>
        <div style={{ opacity: 0.7, marginTop: 4 }}>Atur formasi atau lakukan pergantian pemain sebelum babak kedua.</div>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "center", marginBottom: 15 }}>
        {Object.keys(FORMATIONS).map((name) => (
          <button key={name} onClick={() => { changeFormation(name); setSelectedSlot(null); }} style={{ padding: "8px 11px", borderRadius: 9, border: `1px solid ${name === formation ? GOLD : "rgba(245,239,224,0.18)"}`, background: name === formation ? "rgba(201,162,39,0.18)" : PANEL_SOFT, color: CREAM, fontWeight: 900, cursor: "pointer" }}>{name}</button>
        ))}
      </div>

      <div style={{ marginBottom: 9, fontSize: 12, fontWeight: 900, color: GOLD }}>PILIH POSISI YANG MAU DIGANTI</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(125px, 1fr))", gap: 8 }}>
        {slots.map((slot) => {
          const card = squad[slot.id] ? getCardById(squad[slot.id]) : null;
          const selected = selectedSlot === slot.id;
          return (
            <button key={slot.id} onClick={() => setSelectedSlot(slot.id)} style={{ textAlign: "left", padding: 10, borderRadius: 10, border: `1px solid ${selected ? GOLD : "rgba(245,239,224,0.12)"}`, background: selected ? "rgba(201,162,39,0.12)" : PANEL_SOFT, color: CREAM, cursor: "pointer" }}>
              <div style={{ fontSize: 10, color: GOLD, fontWeight: 900 }}>{slot.label}</div>
              <div style={{ marginTop: 3, fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{card?.name || "Kosong"}</div>
              {card && <div style={{ fontSize: 11, opacity: 0.65 }}>OVR {card.overall}</div>}
            </button>
          );
        })}
      </div>

      {selectedSlotData && (
        <div style={{ marginTop: 15 }}>
          <div style={{ fontSize: 12, fontWeight: 900, marginBottom: 8 }}>{selectedSlotData.label} · {currentCard?.name || "Kosong"} → PILIH PENGGANTI</div>
          {candidates.length === 0 ? (
            <div style={{ opacity: 0.65, padding: 10 }}>Tidak ada kartu cadangan yang cocok untuk posisi ini.</div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))", gap: 8 }}>
              {candidates.map((card) => (
                <button key={card.id} onClick={() => { substitutePlayer(selectedSlot, card.id); setSelectedSlot(null); }} style={{ padding: 10, borderRadius: 10, border: `1px solid ${GOLD}`, background: "rgba(201,162,39,0.1)", color: CREAM, cursor: "pointer", textAlign: "left" }}>
                  <div style={{ fontWeight: 900 }}>{card.name}</div>
                  <div style={{ fontSize: 11, opacity: 0.7 }}>{card.position} · OVR {card.overall}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <button
        onClick={resumeMatch}
        disabled={!squadReady}
        style={{ width: "100%", marginTop: 16, padding: 13, borderRadius: 11, border: `1px solid ${GOLD}`, background: GOLD, color: BG, fontWeight: 1000, cursor: squadReady ? "pointer" : "not-allowed", opacity: squadReady ? 1 : 0.45 }}
      >
        {squadReady ? "▶️ MULAI BABAK KEDUA" : "⚠️ LENGKAPI 11 PEMAIN DULU"}
      </button>
    </div>
  );
}

function MatchBoard({ match, isPlaying, squad, formation }) {
  const [animationTick, setAnimationTick] = useState(0);
  const [playStep, setPlayStep] = useState(0);
  const engineRef = useRef({
    phase: "idle",
    phaseStart: 0,
    duration: 1400,
    possession: "home",
    carrierIndex: 9,
    receiverIndex: 8,
    from: { x: 50, y: 50 },
    to: { x: 50, y: 50 },
    ball: { x: 50, y: 50 },
    eventKey: null,
    setPieceStarted: false,
  });

  const slots = FORMATIONS[formation] || FORMATIONS["4-3-3"];
  const userPlayers = slots.map((slot) => ({
    ...slot,
    card: squad[slot.id] ? getCardById(squad[slot.id]) : null,
  }));

  const opponentNames = [
    "GK", "DEF 1", "DEF 2", "DEF 3", "DEF 4",
    "MID 1", "MID 2", "MID 3", "WING", "ST 1", "ST 2",
  ];

  const events = match.events || [];
  const currentMinute = match.currentMinute || 0;
  const currentMinuteEvents = events.filter((event) => event.minute === currentMinute);
  const lastVisibleEvent = [...events]
    .filter((event) => event.minute <= currentMinute)
    .pop() || null;

  const latestEvent = currentMinuteEvents[currentMinuteEvents.length - 1] || lastVisibleEvent;
  const latestType = latestEvent?.type;

  const actionLabels = {
    attack: "⚔️ SERANGAN",
    pass: "🔄 BUILD UP",
    shot: "🎯 TEMBAKAN!",
    goal: "⚽ GOOOOOL!",
    save: "🧤 PENYELAMATAN",
    corner: "🚩 CORNER",
    out: "↔️ BOLA OUT",
    foul: "🟨 PELANGGARAN",
    freekick: "🎯 FREE KICK",
    penalty: "⚠️ PENALTY!",
    penalty_miss: "🧤 PENALTI GAGAL",
    header: "🧠 SUNDULAN",
    miss: "💨 MELEBAR",
  };

  const setPieceTypes = ["corner", "freekick", "penalty"];
  const isSetPiece = setPieceTypes.includes(latestType);
  const isDeadBall = isSetPiece || latestType === "out" || latestType === "penalty_miss";

  function clamp(value, min = 3, max = 97) {
    return Math.max(min, Math.min(max, value));
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  function easeInOut(t) {
    return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
  }

  function dist(a, b) {
    return Math.hypot(a.x - b.x, a.y - b.y);
  }

  function getFormationPoint(slot, isOpponent = false) {
    return {
      x: slot.x,
      y: isOpponent ? 100 - slot.y : slot.y,
    };
  }

  function roleFor(slot) {
    const p = slot.label;
    if (["ST", "CF"].includes(p)) return "forward";
    if (["LW", "RW", "LM", "RM", "CAM"].includes(p)) return "creator";
    if (["CM", "CDM"].includes(p)) return "midfielder";
    if (["CB", "LB", "RB", "LWB", "RWB"].includes(p)) return "defender";
    return "keeper";
  }

  function chooseCarrier(isHome, preferredIndex = null) {
    const players = isHome ? userPlayers : userPlayers.map((player, index) => ({
      ...player,
      id: `cpu-${index}`,
      x: 100 - player.x,
      y: player.y,
      label: index === 0 ? "GK" : index < 5 ? "CB" : index < 8 ? "CM" : index < 10 ? "RW" : "ST",
    }));

    const candidates = players
      .map((player, index) => ({ player, index }))
      .filter(({ player }) => roleFor(player) !== "keeper");

    if (!candidates.length) return 0;
    if (preferredIndex != null && candidates.some((item) => item.index === preferredIndex)) {
      return preferredIndex;
    }

    const preferredRoles = ["forward", "creator", "midfielder", "defender"];
    const role = preferredRoles[playStep % preferredRoles.length];
    const rolePool = candidates.filter(({ player }) => roleFor(player) === role);
    const pool = rolePool.length ? rolePool : candidates;
    return pool[playStep % pool.length].index;
  }

  function chooseReceiver(isHome, carrierIndex) {
    const players = isHome ? userPlayers : userPlayers.map((player, index) => ({
      ...player,
      id: `cpu-${index}`,
      x: 100 - player.x,
      y: player.y,
      label: index === 0 ? "GK" : index < 5 ? "CB" : index < 8 ? "CM" : index < 10 ? "RW" : "ST",
    }));
    const carrier = players[carrierIndex];
    if (!carrier) return carrierIndex;
    const carrierPos = getFormationPoint(carrier, !isHome);

    const candidates = players
      .map((player, index) => ({ player, index, pos: getFormationPoint(player, !isHome) }))
      .filter(({ index, player }) => index !== carrierIndex && roleFor(player) !== "keeper");

    candidates.sort((a, b) => {
      const score = (item) => {
        const forward = isHome ? (50 - item.pos.y) : (item.pos.y - 50);
        const lateral = Math.abs(item.pos.x - carrierPos.x);
        const distance = dist(item.pos, carrierPos);
        return forward * 0.9 - lateral * 0.15 - distance * 0.35;
      };
      return score(b) - score(a);
    });

    return candidates[0]?.index ?? carrierIndex;
  }

  function normalTarget(slot, index, isOpponent, possession, carrierIndex, ballPosition) {
    const base = getFormationPoint(slot, isOpponent);
    const role = roleFor(slot);
    const isHome = !isOpponent;
    const attacking = possession === (isHome ? "home" : "away");
    const isCarrier = attacking && index === carrierIndex;
    const attackDir = isOpponent ? -1 : 1;

    let x = base.x;
    let y = base.y;

    // Team shape reacts to the real ball location, not an imaginary point.
    const horizontalShift = (ballPosition.x - 50) * (role === "defender" ? 0.10 : role === "midfielder" ? 0.18 : 0.13);
    x += horizontalShift;

    if (attacking) {
      if (role === "forward") y += attackDir * 7;
      if (role === "creator") y += attackDir * 4;
      if (role === "midfielder") y += attackDir * 2.5;

      if (isCarrier) {
        const towardGoal = isHome ? -1 : 1;
        y += towardGoal * 5;
        x += Math.sin((playStep + index) * 0.8) * 2.2;
      } else if (role !== "keeper") {
        const side = index % 2 === 0 ? -1 : 1;
        x += side * 2.5;
        y += attackDir * (index % 3 === 0 ? 2 : -1);
      }
    } else {
      // Defensive block follows the ball and compresses centrally.
      x += (50 - x) * 0.11;
      y += (ballPosition.y - base.y) * 0.10;
      if (role === "defender") y -= attackDir * 1.2;
      if (role === "midfielder") y -= attackDir * 0.5;
    }

    // The nearest defender actually steps toward the ball.
    if (!attacking && role !== "keeper") {
      const distance = dist(base, ballPosition);
      if (distance < 28) {
        const step = Math.min(0.32, (28 - distance) / 90);
        x = lerp(x, ballPosition.x, step);
        y = lerp(y, ballPosition.y, step);
      }
    }

    return { x: clamp(x), y: clamp(y) };
  }

  function getNormalPositions() {
    const engine = engineRef.current;
    const possession = engine.possession;
    const homeCarrier = possession === "home" ? engine.carrierIndex : -1;
    const awayCarrier = possession === "away" ? engine.carrierIndex : -1;
    const ball = engine.ball || { x: 50, y: 50 };

    const home = userPlayers.map((slot, index) => normalTarget(slot, index, false, possession, homeCarrier, ball));
    const away = userPlayers.map((slot, index) => {
      const opponentSlot = {
        ...slot,
        id: `cpu-${index}`,
        label: index === 0 ? "GK" : index < 5 ? "CB" : index < 8 ? "CM" : index < 10 ? "RW" : "ST",
        x: 100 - slot.x,
        y: slot.y,
      };
      return normalTarget(opponentSlot, index, true, possession, awayCarrier, ball);
    });
    return { home, away };
  }

  function getDeadBallPosition(event) {
    if (!event) return { x: 50, y: 50 };
    if (event.type === "corner") {
      return {
        x: event.x <= 50 ? 3.2 : 96.8,
        y: event.y <= 50 ? 3.2 : 96.8,
      };
    }
    if (event.type === "penalty" || event.type === "penalty_miss") {
      return { x: 50, y: event.side === "home" ? 10.5 : 89.5 };
    }
    if (event.type === "freekick") {
      return { x: clamp(event.x, 5, 95), y: clamp(event.y, 5, 95) };
    }
    if (event.type === "out") {
      return {
        x: event.x <= 50 ? 1.8 : 98.2,
        y: clamp(event.y, 4, 96),
      };
    }
    return { x: clamp(event.x ?? 50), y: clamp(event.y ?? 50) };
  }

  function getSetPieceTaker(event) {
    if (!event) return { side: "home", index: 9 };
    const side = event.side === "away" ? "away" : "home";
    const isHome = side === "home";
    const spot = getDeadBallPosition(event);
    const candidates = userPlayers
      .map((slot, index) => ({ slot, index, pos: getFormationPoint(slot, !isHome) }))
      .filter(({ slot }) => roleFor(slot) !== "keeper");

    if (!candidates.length) return { side, index: 0 };

    if (event.type === "corner") {
      const wide = candidates.filter(({ slot }) => ["LW", "RW", "LM", "RM", "LWB", "RWB"].includes(slot.label));
      return { side, index: (wide[0] || candidates[0]).index };
    }

    if (event.type === "penalty" || event.type === "penalty_miss") {
      const forwards = candidates.filter(({ slot }) => ["ST", "CF", "CAM"].includes(slot.label));
      return { side, index: (forwards[0] || candidates[0]).index };
    }

    candidates.sort((a, b) => dist(a.pos, spot) - dist(b.pos, spot));
    return { side, index: candidates[0].index };
  }

  function getTakerPosition(event, taker) {
    const ball = getDeadBallPosition(event);
    if (event?.type === "out") {
      return {
        x: clamp(ball.x <= 50 ? ball.x + 2.7 : ball.x - 2.7),
        y: ball.y,
      };
    }
    if (event?.type === "corner") {
      return {
        x: clamp(ball.x <= 50 ? ball.x + 2.4 : ball.x - 2.4),
        y: clamp(ball.y <= 50 ? ball.y + 2.4 : ball.y - 2.4),
      };
    }
    const side = taker.side === "home" ? 1 : -1;
    return {
      x: clamp(ball.x + (ball.x < 50 ? 2.2 : -2.2)),
      y: clamp(ball.y + side * 1.6),
    };
  }

  function getRestartReceiver(event, taker) {
    const isHome = taker.side === "home";
    const takerIndex = taker.index;
    const candidates = userPlayers
      .map((slot, index) => ({ slot, index, pos: getFormationPoint(slot, !isHome) }))
      .filter(({ index, slot }) => index !== takerIndex && roleFor(slot) !== "keeper");

    if (!candidates.length) return { x: 50, y: 50 };
    const ball = getDeadBallPosition(event);
    candidates.sort((a, b) => dist(a.pos, ball) - dist(b.pos, ball));
    const receiver = candidates[0];
    return getFormationPoint(receiver.slot, !isHome);
  }

  // A short, continuous animation loop keeps the ball and players tied together.
  useEffect(() => {
    if (!isPlaying) return undefined;
    let frame;
    const tick = (now) => {
      const engine = engineRef.current;
      const elapsed = now - engine.phaseStart;
      const t = Math.min(1, engine.duration ? elapsed / engine.duration : 1);
      const eased = easeInOut(t);

      if (engine.phase === "pass" || engine.phase === "restart" || engine.phase === "setpiece") {
        engine.ball = {
          x: lerp(engine.from.x, engine.to.x, eased),
          y: lerp(engine.from.y, engine.to.y, eased),
        };

        if (t >= 1) {
          if (engine.phase === "setpiece") {
            // The taker has reached the dead ball. Hold the ball there briefly
            // before the actual kick/throw starts.
            engine.phase = "restart";
            engine.from = { ...engine.to };
            engine.phaseStart = now;
            engine.duration = 1050;
            engine.ball = { ...engine.to };
          } else {
            // A pass/restart has reached the receiver. The ball stays exactly
            // where it arrived and only then becomes attached to that player.
            engine.phase = "carry";
            engine.carrierIndex = engine.receiverIndex;
            engine.phaseStart = now;
            engine.duration = 1500;
            engine.ball = { ...engine.to };
          }
        }
      } else if (engine.phase === "carry") {
        const isHome = engine.possession === "home";
        const carrier = engine.carrierIndex;
        const slot = userPlayers[carrier];
        if (slot) {
          const target = normalTarget(slot, carrier, false, engine.possession, isHome ? carrier : -1, engine.ball);
          const actualTarget = isHome
            ? target
            : normalTarget({
                ...slot,
                id: `cpu-${carrier}`,
                label: carrier === 0 ? "GK" : carrier < 5 ? "CB" : carrier < 8 ? "CM" : carrier < 10 ? "RW" : "ST",
                x: 100 - slot.x,
                y: slot.y,
              }, carrier, true, engine.possession, carrier, engine.ball);
          engine.ball = { ...actualTarget };
        }

        if (t >= 1) {
          const nextCarrier = engine.carrierIndex;
          const nextReceiver = chooseReceiver(engine.possession, nextCarrier);
          const positions = getNormalPositions();
          const from = { ...engine.ball };
          const to = engine.possession === "home"
            ? positions.home[nextReceiver]
            : positions.away[nextReceiver];

          // Never restart a pass from an old formation coordinate. Start it
          // from the ball's exact current position so there is no visible snap.
          engine.carrierIndex = nextCarrier;
          engine.receiverIndex = nextReceiver;
          engine.phase = "pass";
          engine.from = { ...from };
          engine.to = { ...to };
          engine.ball = { ...from };
          engine.phaseStart = now;
          engine.duration = 1350;
        }
      }

      if (engine.phase === "shot" && t >= 1) {
        engine.ball = { ...engine.to };
      }

      setAnimationTick((value) => value + 1);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [isPlaying]);

  useEffect(() => {
    if (!isPlaying) return;
    const engine = engineRef.current;
    if (engine.phase === "idle") {
      engine.possession = "home";
      engine.carrierIndex = chooseCarrier(true, 9);
      engine.receiverIndex = chooseReceiver(true, engine.carrierIndex);
      const positions = getNormalPositions();
      engine.ball = { ...positions.home[engine.carrierIndex] };
      engine.phase = "carry";
      engine.phaseStart = performance.now();
      engine.duration = 1500;
    }
  }, [isPlaying]);

  // Open-play is driven by the same requestAnimationFrame loop as the ball.
  // This is important: a second timer must never overwrite the current phase,
  // otherwise the ball appears to teleport from one player to another.

  // Every event gets one coherent visual sequence. Set pieces have an actual
  // taker, then the ball travels to a receiver instead of floating in place.
  useEffect(() => {
    if (!isPlaying || !latestEvent) return undefined;
    const key = `${latestEvent.id}-${latestType}-${currentMinute}`;
    const engine = engineRef.current;
    if (engine.eventKey === key) return undefined;

    engine.eventKey = key;
    if (isDeadBall) {
      const taker = getSetPieceTaker(latestEvent);
      const ball = getDeadBallPosition(latestEvent);
      const takerPos = getTakerPosition(latestEvent, taker);
      const receiver = getRestartReceiver(latestEvent, taker);
      engine.possession = taker.side;
      engine.carrierIndex = taker.index;
      engine.receiverIndex = 0;
      engine.phase = "setpiece";
      engine.from = takerPos;
      engine.to = ball;
      engine.ball = { ...ball };
      engine.phaseStart = performance.now();
      engine.duration = 550;

      const restartTimer = setTimeout(() => {
        const active = engineRef.current;
        active.phase = "restart";
        active.from = { ...ball };
        active.to = { ...receiver };
        active.ball = { ...ball };
        active.phaseStart = performance.now();
        active.duration = latestType === "out" ? 850 : 1050;
      }, 650);
      return () => clearTimeout(restartTimer);
    }

    if (["shot", "header", "goal", "save", "miss"].includes(latestType)) {
      const side = latestEvent.side === "away" ? "away" : "home";
      const isHome = side === "home";
      const carrier = chooseCarrier(isHome);
      const positions = getNormalPositions();
      const start = isHome ? positions.home[carrier] : positions.away[carrier];
      const target = latestType === "save"
        ? { x: 50, y: isHome ? 95 : 5 }
        : { x: 50, y: isHome ? 3.8 : 96.2 };
      engine.possession = side;
      engine.carrierIndex = carrier;
      engine.phase = "shot";
      engine.from = { ...start };
      engine.to = target;
      engine.ball = { ...start };
      engine.phaseStart = performance.now();
      engine.duration = latestType === "goal" ? 650 : 850;
    }

    return undefined;
  }, [latestEvent?.id, latestType, currentMinute, isPlaying, isDeadBall]);

  function getEngineProgress() {
    const engine = engineRef.current;
    return Math.min(1, Math.max(0, (performance.now() - engine.phaseStart) / Math.max(1, engine.duration)));
  }

  function getBallPosition() {
    const engine = engineRef.current;
    const progress = easeInOut(getEngineProgress());

    if (engine.phase === "pass" || engine.phase === "restart" || engine.phase === "setpiece" || engine.phase === "shot") {
      return {
        x: lerp(engine.from.x, engine.to.x, progress),
        y: lerp(engine.from.y, engine.to.y, progress),
      };
    }

    return engine.ball;
  }

  const ball = getBallPosition();
  const normalPositions = getNormalPositions();
  const taker = isDeadBall ? getSetPieceTaker(latestEvent) : null;
  const takerIsHome = taker?.side === "home";
  const restartPhase = engineRef.current.phase === "restart";

  function playerPosition(slot, index, isOpponent) {
    if (isDeadBall) {
      const base = getFormationPoint(slot, isOpponent);
      if (taker && ((takerIsHome && !isOpponent && index === taker.index) || (!takerIsHome && isOpponent && index === taker.index))) {
        const takerPos = getTakerPosition(latestEvent, taker);
        const p = engineRef.current.phase === "setpiece" ? easeInOut(getEngineProgress()) : 1;
        return {
          x: lerp(base.x, takerPos.x, p),
          y: lerp(base.y, takerPos.y, p),
        };
      }

      // During the restart, nearby teammates step toward the ball while the
      // rest of the shape stays compact.
      const ballPoint = getDeadBallPosition(latestEvent);
      const near = dist(base, ballPoint) < 30;
      if (restartPhase && near && roleFor(slot) !== "keeper") {
        return {
          x: lerp(base.x, ballPoint.x, 0.18),
          y: lerp(base.y, ballPoint.y, 0.18),
        };
      }
      return base;
    }

    const target = isOpponent ? normalPositions.away[index] : normalPositions.home[index];
    const base = getFormationPoint(slot, isOpponent);
    const p = 0.55 + easeInOut(getEngineProgress()) * 0.45;
    return {
      x: lerp(base.x, target.x, p),
      y: lerp(base.y, target.y, p),
    };
  }

  const showAction = isPlaying && latestEvent;
  const actionText = latestEvent ? actionLabels[latestType] || "MATCH" : "MATCH";

  return (
    <div style={{ position: "relative", width: "100%", aspectRatio: "16 / 10", borderRadius: 20, overflow: "hidden", border: "3px solid rgba(245,239,224,0.25)", background: "linear-gradient(90deg, #17351f, #20552e, #17351f)", boxShadow: "0 20px 45px rgba(0,0,0,0.35)" }}>
      <div style={{ position: "absolute", inset: 0, background: "repeating-linear-gradient(90deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 55px, transparent 55px, transparent 110px)" }} />
      <div style={{ position: "absolute", inset: "1.2%", border: "2.5px solid rgba(255,255,255,0.82)", zIndex: 1 }} />
      <div style={{ position: "absolute", left: "1.2%", right: "1.2%", top: "50%", borderTop: "2px solid rgba(255,255,255,0.72)", zIndex: 1 }} />
      <div style={{ position: "absolute", width: 105, height: 105, border: "2px solid rgba(255,255,255,0.68)", borderRadius: "50%", left: "50%", top: "50%", transform: "translate(-50%, -50%)", zIndex: 1 }} />
      <div style={{ position: "absolute", width: 7, height: 7, background: "rgba(255,255,255,0.9)", borderRadius: "50%", left: "50%", top: "50%", transform: "translate(-50%, -50%)", zIndex: 2 }} />
      <div style={{ position: "absolute", width: "34%", height: "18%", left: "33%", top: "1.2%", border: "2px solid rgba(255,255,255,0.68)", borderTop: "none", zIndex: 1 }} />
      <div style={{ position: "absolute", width: "34%", height: "18%", left: "33%", bottom: "1.2%", border: "2px solid rgba(255,255,255,0.68)", borderBottom: "none", zIndex: 1 }} />
      <div style={{ position: "absolute", width: "15%", height: "7%", left: "42.5%", top: "1.2%", border: "2px solid rgba(255,255,255,0.62)", borderTop: "none", zIndex: 1 }} />
      <div style={{ position: "absolute", width: "15%", height: "7%", left: "42.5%", bottom: "1.2%", border: "2px solid rgba(255,255,255,0.62)", borderBottom: "none", zIndex: 1 }} />
      <div style={{ position: "absolute", width: "17%", height: "5.5%", left: "41.5%", top: "-1.2%", border: "3px solid rgba(255,255,255,0.92)", borderBottom: "4px solid rgba(255,255,255,0.92)", background: "repeating-linear-gradient(135deg, rgba(255,255,255,0.12) 0px, rgba(255,255,255,0.12) 5px, transparent 5px, transparent 10px)", boxSizing: "border-box", zIndex: 3 }} />
      <div style={{ position: "absolute", width: "17%", height: "5.5%", left: "41.5%", bottom: "-1.2%", border: "3px solid rgba(255,255,255,0.92)", borderTop: "4px solid rgba(255,255,255,0.92)", background: "repeating-linear-gradient(45deg, rgba(255,255,255,0.12) 0px, rgba(255,255,255,0.12) 5px, transparent 5px, transparent 10px)", boxSizing: "border-box", zIndex: 3 }} />
      {["leftTop", "rightTop", "leftBottom", "rightBottom"].map((corner) => {
        const style = {
          leftTop: { left: "1.2%", top: "1.2%", borderRight: "2px solid rgba(255,255,255,0.68)", borderBottom: "2px solid rgba(255,255,255,0.68)", borderRadius: "0 0 100% 0" },
          rightTop: { right: "1.2%", top: "1.2%", borderLeft: "2px solid rgba(255,255,255,0.68)", borderBottom: "2px solid rgba(255,255,255,0.68)", borderRadius: "0 0 0 100%" },
          leftBottom: { left: "1.2%", bottom: "1.2%", borderRight: "2px solid rgba(255,255,255,0.68)", borderTop: "2px solid rgba(255,255,255,0.68)", borderRadius: "0 100% 0 0" },
          rightBottom: { right: "1.2%", bottom: "1.2%", borderLeft: "2px solid rgba(255,255,255,0.68)", borderTop: "2px solid rgba(255,255,255,0.68)", borderRadius: "100% 0 0 0" },
        }[corner];
        return <div key={corner} style={{ position: "absolute", width: 30, height: 30, ...style, zIndex: 1 }} />;
      })}

      {userPlayers.map((player, index) => {
        const pos = playerPosition(player, index, false);
        const isTaker = takerIsHome && taker?.index === index;
        return <MatchPlayerMarker key={`home-${player.id}`} card={player.card} fallbackLabel={player.label} x={pos.x} y={pos.y} home moving={isPlaying && !isDeadBall} holdingBall={isTaker && isDeadBall} />;
      })}

      {userPlayers.map((player, index) => {
        const opponentSlot = {
          ...player,
          id: `cpu-${index}`,
          label: index === 0 ? "GK" : index < 5 ? "CB" : index < 8 ? "CM" : index < 10 ? "RW" : "ST",
          x: 100 - player.x,
          y: player.y,
        };
        const pos = playerPosition(opponentSlot, index, true);
        const isTaker = !takerIsHome && taker?.index === index;
        return <MatchPlayerMarker key={`away-${index}`} card={null} fallbackLabel={opponentNames[index] || "CPU"} x={pos.x} y={pos.y} home={false} moving={isPlaying && !isDeadBall} holdingBall={isTaker && isDeadBall} />;
      })}

      <div
        style={{
          position: "absolute",
          left: `${ball.x}%`,
          top: `${ball.y}%`,
          transform: "translate(-50%, -50%)",
          transition: "left 0.06s linear, top 0.06s linear",
          width: latestType === "goal" ? 22 : 17,
          height: latestType === "goal" ? 22 : 17,
          borderRadius: "50%",
          background: "radial-gradient(circle at 35% 30%, #fff, #e7e7e7 55%, #aaa)",
          border: "2px solid #111",
          boxShadow: "0 3px 8px rgba(0,0,0,0.45)",
          zIndex: 20,
          pointerEvents: "none",
        }}
      />

      {showAction && (
        <div key={`${latestEvent.id}-${latestType}`} style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%, -50%)", zIndex: 40, padding: "12px 22px", borderRadius: 14, background: latestType === "goal" ? "rgba(20,120,45,0.94)" : latestType === "penalty" ? "rgba(150,45,35,0.95)" : "rgba(12,15,12,0.82)", border: `2px solid ${latestType === "goal" ? "#ffe27a" : "rgba(245,239,224,0.5)"}`, color: "#fff", fontWeight: 1000, fontSize: latestType === "goal" ? 25 : 18, letterSpacing: 1, boxShadow: "0 12px 35px rgba(0,0,0,0.45)", whiteSpace: "nowrap" }}>
          {actionText}
        </div>
      )}

      {isDeadBall && isPlaying && (
        <div style={{ position: "absolute", left: "50%", bottom: 14, transform: "translateX(-50%)", zIndex: 45, padding: "6px 12px", borderRadius: 9, background: "rgba(0,0,0,0.72)", border: "1px solid rgba(245,239,224,0.25)", fontSize: 11, fontWeight: 900, color: "#fff" }}>
          {latestType === "corner" ? "Pemain bersiap mengambil corner" : latestType === "freekick" ? "Pemain bersiap mengambil free kick" : latestType === "penalty" || latestType === "penalty_miss" ? "Pemain mengambil penalti" : "Pemain mengambil throw-in"}
        </div>
      )}

      <div style={{ position: "absolute", left: 12, bottom: 10, padding: "5px 9px", borderRadius: 8, background: "rgba(20,60,180,0.82)", fontSize: 10, fontWeight: 900, zIndex: 25 }}>RALOU FC</div>
      <div style={{ position: "absolute", right: 12, top: 10, padding: "5px 9px", borderRadius: 8, background: "rgba(150,35,35,0.82)", fontSize: 10, fontWeight: 900, zIndex: 25 }}>{match.opponent.name}</div>
    </div>
  );
}

function MatchPlayerMarker({ card, fallbackLabel, x, y, home, moving, holdingBall = false }) {
  const label = card ? card.name.split(" ").slice(-1)[0] : fallbackLabel;
  const overall = card?.overall;

  return (
    <div
      style={{
        position: "absolute",
        left: `${x}%`,
        top: `${y}%`,
        transform: "translate(-50%, -50%)",
        zIndex: 10,
        transition: moving ? "left 0.25s linear, top 0.25s linear" : "left 0.35s ease, top 0.35s ease",
        textAlign: "center",
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          width: 32,
          height: 32,
          borderRadius: "50%",
          border: `2px solid ${home ? "#66aaff" : "#ff7373"}`,
          background: home ? "#1e5bc6" : "#b72e35",
          boxShadow: home
            ? "0 0 12px rgba(70,140,255,0.45)"
            : "0 0 12px rgba(255,80,80,0.4)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 10,
          fontWeight: 900,
          color: "#fff",
        }}
      >
        {overall || ""}
      </div>
      <div
        style={{
          marginTop: 2,
          maxWidth: 72,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
          fontSize: 9,
          fontWeight: 900,
          textShadow: "0 1px 3px rgba(0,0,0,0.9)",
        }}
      >
        {label}
      </div>
    </div>
  );
}

function HistoryPanel({ history }) {
  if (history.length === 0) {
    return (
      <div style={emptyStyle()}>
        Belum ada riwayat pertandingan.
        <br />
        Mainkan match pertama lu.
      </div>
    );
  }

  return (
    <div
      style={{
        background: PANEL,
        borderRadius: 20,
        padding: 22,
        border: "1px solid rgba(201,162,39,0.3)",
      }}
    >
      <h2 style={{ color: GOLD, marginTop: 0 }}>Match History</h2>

      <div
        style={{
          display: "grid",
          gap: 10,
        }}
      >
        {history.map((item) => (
          <div
            key={item.id}
            style={{
              display: "grid",
              gridTemplateColumns: "90px 1fr auto",
              gap: 12,
              alignItems: "center",
              background: PANEL_SOFT,
              borderRadius: 12,
              padding: 13,
            }}
          >
            <div
              style={{
                fontWeight: 900,
                color:
                  item.result === "WIN"
                    ? "#69d27c"
                    : item.result === "LOSS"
                    ? "#ff7777"
                    : GOLD,
              }}
            >
              {item.result}
            </div>

            <div>
              <div style={{ fontWeight: 900 }}>
                RALOU FC {item.userGoals} - {item.oppGoals} {item.opponent}
              </div>
              <div style={{ fontSize: 12, opacity: 0.55, marginTop: 3 }}>
                {item.date} · OVR {item.userOverall} vs {item.opponentOverall}
              </div>
            </div>

            <div style={{ fontWeight: 900, color: GOLD }}>
              +{item.reward} 🪙
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function StatBox({ label, value }) {
  return (
    <div
      style={{
        minWidth: 70,
        textAlign: "center",
        background: PANEL_SOFT,
        borderRadius: 10,
        padding: "7px 9px",
        border: "1px solid rgba(201,162,39,0.2)",
      }}
    >
      <div style={{ fontSize: 10, opacity: 0.65, fontWeight: 900 }}>
        {label}
      </div>
      <div style={{ color: GOLD, fontSize: 18, fontWeight: 900 }}>
        {value}
      </div>
    </div>
  );
}

function PitchPlayer({ card, label, active, onClick }) {
  if (!card) {
    return (
      <button
        onClick={onClick}
        style={{
          width: 78,
          height: 78,
          borderRadius: "50%",
          border: active
            ? `3px solid ${GOLD}`
            : "2px dashed rgba(245,239,224,0.55)",
          background: "rgba(20,40,25,0.85)",
          color: CREAM,
          cursor: "pointer",
          boxShadow: active
            ? "0 0 25px rgba(201,162,39,0.65)"
            : "0 5px 15px rgba(0,0,0,0.25)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <div style={{ fontSize: 25, fontWeight: 900 }}>+</div>
        <div style={{ fontSize: 10, fontWeight: 900 }}>{label}</div>
      </button>
    );
  }

  return (
    <button
      onClick={onClick}
      style={{
        width: 112,
        minHeight: 110,
        borderRadius: 14,
        border: active
          ? `3px solid ${GOLD}`
          : "2px solid rgba(245,239,224,0.35)",
        background: "linear-gradient(145deg, #2c2618, #12110e)",
        color: CREAM,
        cursor: "pointer",
        padding: 7,
        boxShadow: active
          ? "0 0 28px rgba(201,162,39,0.7)"
          : "0 7px 20px rgba(0,0,0,0.4)",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          fontSize: 10,
          fontWeight: 900,
          color: GOLD,
        }}
      >
        <span>{label}</span>
        <span>{card.overall}</span>
      </div>

      <div
        style={{
          height: 54,
          marginTop: 4,
          borderRadius: 8,
          background: "linear-gradient(180deg, #403823, #211d16)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 27,
        }}
      >
        ⚽
      </div>

      <div
        style={{
          marginTop: 5,
          fontSize: 11,
          fontWeight: 900,
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
        }}
      >
        {card.name}
      </div>

      <div
        style={{
          fontSize: 9,
          opacity: 0.65,
          marginTop: 2,
        }}
      >
        {card.position}
      </div>
    </button>
  );
}

function buttonStyle() {
  return {
    padding: "10px 15px",
    borderRadius: 10,
    border: `1px solid ${GOLD}`,
    background: PANEL_SOFT,
    color: CREAM,
    fontWeight: 900,
    cursor: "pointer",
  };
}

function emptyStyle() {
  return {
    background: PANEL,
    borderRadius: 18,
    padding: 50,
    textAlign: "center",
    border: "1px solid rgba(201,162,39,0.25)",
    opacity: 0.8,
    lineHeight: 1.7,
  };
}
